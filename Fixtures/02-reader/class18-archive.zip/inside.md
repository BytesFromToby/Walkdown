Instructions inside an archive are not read by Walkdown.
