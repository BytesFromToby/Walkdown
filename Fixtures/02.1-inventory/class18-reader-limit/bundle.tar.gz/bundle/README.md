WALKDOWN FIXTURE :: a tar holding programs (POSITIVE)
