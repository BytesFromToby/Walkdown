WALKDOWN FIXTURE :: a tar holding text only (NEGATIVE)
